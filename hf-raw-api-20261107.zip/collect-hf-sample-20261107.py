"""Public, unauthenticated publisher-account sample. Never a national census."""
import concurrent.futures, datetime, json, pathlib, re, urllib.parse, urllib.request

OUT = pathlib.Path(__file__).resolve().parent / 'hf-snapshots-20261107'
OUT.mkdir(exist_ok=True)
ACCOUNTS = {
 'meta-llama':'US', 'google':'US', 'openai':'US', 'nvidia':'US', 'microsoft':'US', 'ibm-granite':'US', 'amazon':'US',
 'Qwen':'CN', 'deepseek-ai':'CN', 'zai-org':'CN', 'moonshotai':'CN', 'MiniMaxAI':'CN',
 'tencent':'CN', 'XiaomiMiMo':'CN', 'inclusionAI':'CN', 'baidu':'CN', 'BAAI':'CN',
 'mistralai':'FR', 'stabilityai':'GB', 'Aleph-Alpha':'DE', 'CohereLabs':'CA',
 'llm-jp':'JP', 'LGAI-EXAONE':'KR', 'sarvamai':'IN', 'tiiuae':'AE',
 'humain-ai':'SA', 'aisingapore':'SG', 'mesolitica':'MY', 'Sahabat-AI':'ID',
 'vinai':'VN', 'typhoon-ai':'TH', 'AIInstituteLNCC':'BR', 'latam-gpt':'CL',
 'lelapa':'ZA', 'Jacaranda':'KE', 'NCAIR1':'NG', 'Applied-Innovation-Center':'EG',
 'atlasia':'MA', 'issai':'KZ', 'TURKCELL':'TR'
}
TEXT_TASKS = {'text-generation','text2text-generation','image-text-to-text','audio-text-to-text','any-to-any'}
WEIGHT_RE = re.compile(r'\.(safetensors|bin|gguf|pt|pth|ckpt|h5|npz|onnx)$', re.I)

def fetch(account, iso):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    initial = 'https://huggingface.co/api/models?' + urllib.parse.urlencode({'author':account,'limit':1000,'full':'true','cardData':'true'})
    url, pages, models = initial, [], []
    try:
        while url:
            req=urllib.request.Request(url,headers={'User-Agent':'AI-Capacity-Atlas-Research/1.0'})
            with urllib.request.urlopen(req,timeout=45) as response:
                page=json.load(response)
                link=response.headers.get('Link','')
            if not isinstance(page,list): raise ValueError('API returned a non-list')
            pages.append({'url':url,'rows':len(page),'link':link})
            models.extend(page)
            next_match=re.search(r'<([^>]+)>;\s*rel="next"',link)
            url=next_match.group(1) if next_match else None
        (OUT / (account+'.raw.json')).write_text(json.dumps({'fetchedAt':started,'pages':pages,'models':models},ensure_ascii=False),encoding='utf-8')
        rows=[]
        for model in models:
            files=[x.get('rfilename','') for x in model.get('siblings',[])]
            card=model.get('cardData') or {}
            weights=[x for x in files if WEIGHT_RE.search(x) and not any(t in x.lower() for t in ['optimizer','training_args','scheduler','rng_state']) and not (x.lower().endswith(('.bin','.onnx','.npz')) and any(t in x.split('/')[-1].lower() for t in ['tokenizer','spiece','vocab','merges','dictionary']))]
            license_value=card.get('license') or [t[8:] for t in model.get('tags',[]) if t.startswith('license:')]
            rows.append({'id':model['id'],'author':model.get('author'),'pipelineTag':model.get('pipeline_tag'),'downloads30d':model.get('downloads'),
                         'license':license_value,'gated':model.get('gated'),'private':model.get('private'),
                         'createdAt':model.get('createdAt'),'lastModified':model.get('lastModified'),'sha':model.get('sha'),
                         'hasWeightFile':bool(weights),'weightFileCount':len(weights),
                         'weightDetection':'recognized_weight_file' if weights else 'no_recognized_weight_file',
                         'hasAdapterWeightFile':any('adapter' in x.lower() for x in weights),
                         'quantizationVariantDeclared':any(t.startswith('base_model:quantized:') for t in model.get('tags',[])) or any(x.lower().endswith('.gguf') for x in weights),
                         'strictGenerativeLanguageTask':model.get('pipeline_tag') in TEXT_TASKS,
                         'baseModelDeclared':card.get('base_model'), 'url':'https://huggingface.co/'+model['id']})
        public=[x for x in rows if x.get('private') is not True]
        weighted=[x for x in public if x['hasWeightFile']]
        generative=[x for x in weighted if x['strictGenerativeLanguageTask']]
        result={'account':account,'countryMapping':iso,'fetchedAt':started,'sourceUrl':initial,'paginationComplete':True,
                'publicRepoCount':len(public),'weightArtifactRepoCount':len(weighted),'weightArtifactDownloads30d':sum(x['downloads30d'] or 0 for x in weighted),
                'allPublicRepoDownloads30d':sum(x['downloads30d'] or 0 for x in public),
                'generativeTaskWeightRepoCount':len(generative),'generativeTaskDownloads30d':sum(x['downloads30d'] or 0 for x in generative),
                'gatedWeightRepoCount':sum(bool(x['gated']) for x in weighted),
                'adapterWeightRepoCount':sum(x['hasAdapterWeightFile'] for x in weighted),
                'quantizationVariantRepoCount':sum(x['quantizationVariantDeclared'] for x in weighted),'downloadsMissingCount':sum(x['downloads30d'] is None for x in weighted),
                'topGenerativeRepos':sorted(generative,key=lambda x:x['downloads30d'] or 0,reverse=True)[:5],
                'rows':rows}
        return result
    except Exception as e:
        return {'account':account,'countryMapping':iso,'fetchedAt':started,'sourceUrl':initial,'paginationComplete':False,'error':type(e).__name__+': '+str(e)}

if __name__ == '__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    results=list(pool.map(lambda x:fetch(*x),ACCOUNTS.items()))
 final={'asOf':'2026-11-07','scope':'40 selected official publisher accounts; not national totals; all modalities and strict generative-language task slice both retained',
       'tasks':sorted(TEXT_TASKS),'weightFileDetection':'File-list suffix heuristic; not an audit of checkpoint completeness, accessibility, or OSI license compliance.',
       'accounts':results}
 (OUT/'summary.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in results:
    print(r['countryMapping'],r['account'],r.get('publicRepoCount'),r.get('weightArtifactRepoCount'),r.get('weightArtifactDownloads30d'),r.get('generativeTaskWeightRepoCount'),r.get('generativeTaskDownloads30d'),r.get('error',''),flush=True)
