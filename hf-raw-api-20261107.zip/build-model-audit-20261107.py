import collections, hashlib, json, pathlib, zipfile

ROOT=pathlib.Path(__file__).resolve().parent
old=json.loads((ROOT.parent/'ai-capacity-atlas/evidence/models-31-countries.json').read_text())
raw=json.loads((ROOT/'hf-snapshots-20261107/summary.json').read_text())

names={
 'meta-llama':'Meta / Llama','google':'Google','openai':'OpenAI','nvidia':'NVIDIA','microsoft':'Microsoft','ibm-granite':'IBM Granite','amazon':'Amazon',
 'Qwen':'阿里巴巴 / Qwen','deepseek-ai':'DeepSeek','zai-org':'智谱 / Z AI','moonshotai':'月之暗面 / Kimi',
 'MiniMaxAI':'MiniMax','tencent':'腾讯','XiaomiMiMo':'小米 / MiMo','inclusionAI':'蚂蚁 / InclusionAI','baidu':'百度 / ERNIE','BAAI':'北京智源 BAAI',
 'mistralai':'Mistral AI','stabilityai':'Stability AI','Aleph-Alpha':'Aleph Alpha','CohereLabs':'Cohere Labs',
 'llm-jp':'日本 NII / LLM-jp','LGAI-EXAONE':'LG AI Research','sarvamai':'Sarvam AI','tiiuae':'TII / Falcon',
 'humain-ai':'HUMAIN / ALLaM（SDAIA 原研发）','aisingapore':'AI Singapore','mesolitica':'Mesolitica',
 'Sahabat-AI':'Sahabat-AI（GoTo / Indosat，AI Singapore 合作）','vinai':'VinAI','typhoon-ai':'Typhoon / SCB 10X',
 'AIInstituteLNCC':'LNCC 人工智能研究所','latam-gpt':'LatamGPT（CENIA 协调的区域合作）','lelapa':'Lelapa AI',
 'Jacaranda':'Jacaranda Health','NCAIR1':'尼日利亚 NCAIR','Applied-Innovation-Center':'埃及 AIC',
 'atlasia':'AtlasIA 摩洛哥社区','issai':'纳扎尔巴耶夫大学 ISSAI','TURKCELL':'Turkcell'
}

country_notes={
 'US':'7个账号样本；包含语音、视觉等模型。Anthropic等闭源厂商不在HF权重样本，不代表其无模型能力。Google研发跨国。',
 'CN':'10个账号样本；不可与美国7账号样本之比解读为全国份额。未汇总所有社区衍生账号或ModelScope。',
 'GB':'按Stability AI英国起源及机构关联归类，跨国团队与资本不等于英国独占控制。',
 'DE':'按Aleph Alpha发布主体历史归属；2026-09已签与Cohere合并协议，不能未经交割核实直接改成加拿大独占。',
 'CA':'Cohere Labs为跨国团队；已宣布与Aleph Alpha合并，按本次发布账号传统归属归类，非所有权百分比分摊。',
 'BR':'仅LNCC公开账号样本；不含闭源Sabiá收入或API调用。Manacá为LNCC×日本NII合作。',
 'CL':'LatamGPT为区域合作，按CENIA协调节点归智利仅为统计分组，不能把共同成果各参与国重复加总。',
 'ID':'Sahabat-AI含AI Singapore研发合作；本地机构账号样本不等于研发劳动或价值留存全在印尼。',
 'KE':'Jacaranda Health为跨国非营利组织、面向肯尼亚项目；计机构案例关联，不作全国自主产权认定。',
 'MA':'AtlasIA是社区主体；不能称政府官方模型总量。',
 'SA':'ALLaM当前发布账号为humain-ai，原开发机构为SDAIA/NCAI；发布与研发归属分开。',
 'TH':'原scb10x账号已迁移至typhoon-ai，旧账号空返回已剔除，不计为零模型。'
}

metrics=['publicRepoCount','allPublicRepoDownloads30d','weightArtifactRepoCount','weightArtifactDownloads30d',
         'generativeTaskWeightRepoCount','generativeTaskDownloads30d','gatedWeightRepoCount','downloadsMissingCount','adapterWeightRepoCount','quantizationVariantRepoCount']
accounts=[]
for a in raw['accounts']:
    b={k:v for k,v in a.items() if k not in ['rows','topGenerativeRepos']}
    b['publisher']=names[a['account']]
    b['accountUrl']='https://huggingface.co/'+a['account']
    b['identitySources']=[b['accountUrl']]
    if a['account']=='amazon':b['identitySources'].append('https://github.com/amazon-science/chronos-forecasting')
    if a['account']=='baidu':b['identitySources'].append('https://ernie.baidu.com/blog/publication/ERNIE_Technical_Report.pdf')
    if a['account']=='ibm-granite':b['identitySources'].append('https://www.ibm.com/granite')
    if a['account']=='microsoft':b['identitySources'].append('https://huggingface.co/microsoft/Phi-4-mini-instruct')
    b['countryAttribution']='发布机构主要归属／当地项目关联，非用户所在地、服务器所在地或股权份额'
    b['scope']='该账号全部公开仓库；默认指标仅保留文件列表可识别权重的仓库'
    b['rawSnapshotFile']='hf-snapshots-20261107/'+a['account']+'.raw.json'
    b['topWeightRepos']=sorted([r for r in a['rows'] if r['hasWeightFile']],key=lambda r:r['downloads30d'] or 0,reverse=True)[:3]
    b['missingTaskLabelWeightRepoCount']=sum(r['hasWeightFile'] and not r['pipelineTag'] for r in a['rows'])
    accounts.append(b)

countries=[]
for c in old['countries']:
    selected=[a for a in accounts if a['countryMapping']==c['iso']]
    row={'iso':c['iso'],'country':c['country'],'status':'included_sample' if selected else 'not_in_sample',
         'accountCount':len(selected),'accounts':[a['account'] for a in selected],
         'note':country_notes.get(c['iso'],'仅所列账号样本，非全国总量。') if selected else '本轮尚未核实可纳入的本地发布机构账号；缺失不是零。'}
    row.update({m:sum(a[m] for a in selected) if selected else None for m in metrics})
    row['missingTaskLabelWeightRepoCount']=sum(a['missingTaskLabelWeightRepoCount'] for a in selected) if selected else None
    countries.append(row)

method_sources=[
 {'title':'Hugging Face Models Download Stats','url':'https://huggingface.co/docs/hub/models-download-stats','supports':'服务端按query files的GET/HEAD请求计数；GGUF可能重复；不是唯一用户'},
 {'title':'Hugging Face Hub API Endpoints','url':'https://huggingface.co/docs/hub/api','supports':'公开模型列表API与分页来源'},
 {'title':'Hugging Face Hub API参考','url':'https://huggingface.co/docs/huggingface_hub/package_reference/hf_api','supports':'ModelInfo.downloads字段：最近30日'},
 {'title':'OSI Open Source AI Definition 1.0','url':'https://opensource.org/ai/open-source-ai-definition','supports':'模型参数可下载不足以满足开源AI；还需数据说明、代码及权利要求'}
]

ecosystem={
 'schemaVersion':'1.0','asOf':'2026-11-07','title':'开放模型生态（代表机构公开权重仓库样本）',
 'snapshotStartedAt':min(a['fetchedAt'] for a in accounts),'snapshotEndedAt':max(a['fetchedAt'] for a in accounts),
 'coverage':{'plannedCountries':31,'includedCountries':25,'includedPublisherAccounts':len(accounts),'publicRepos':sum(a['publicRepoCount'] for a in accounts),'weightArtifactRepos':sum(a['weightArtifactRepoCount'] for a in accounts)},
 'defaultMetrics':['weightArtifactRepoCount','weightArtifactDownloads30d'],
 'metricDefinitions':{
   'weightArtifactRepoCount':'公开仓库中，文件列表包含至少一个可识别权重文件的仓库数；含量化、不同精度、不同版本、适配器和受限访问仓库；不等于独立模型家族数。',
   'weightArtifactDownloads30d':'上述同一仓库子集的Hugging Face downloads字段之和，统计窗口为抓取时刻之前30天。按发布机构归属分组的是全球下载请求，不是该国用户下载。',
   'publicRepoCount':'该账号完整分页返回的全部公开模型仓库数；包含仅说明页或尚无可识别权重的仓库。',
   'allPublicRepoDownloads30d':'全部公开仓库的downloads之和，仅与publicRepoCount口径配套。',
   'generativeTaskWeightRepoCount':'具有text-generation、text2text-generation、image-text-to-text、audio-text-to-text或any-to-any标签的权重仓库数，仅为标签可识别下限。',
   'generativeTaskDownloads30d':'上述标签可识别下限子集的downloads合计，不代表完整LLM下载量。',
   'gatedWeightRepoCount':'权重仓库中gated字段不为false者；可能需要接受条款或申请访问。',
   'adapterWeightRepoCount':'含adapter命名权重文件的仓库下限，已包含在默认计数中；不是全量适配模型数。',
   'quantizationVariantRepoCount':'元数据标记为量化衍生或含GGUF文件的仓库下限，已包含在默认计数中；可与adapter、gated重叠。'
 },
 'warnings':[
   '仅代表机构账号样本，账号选择及数量不同，不能据此计算全国市场份额或全球总份额。',
   '公开权重不等于严格开源。本轮未逐一审计OSI开源AI合规，不发布所谓开源模型总数。Apache/MIT等标签也不能单独证明完整AI系统符合OSI定义。',
   '仓库是统计单位；量化、精度、基座/指令版、旧版本、转换版、适配器均可能单独成仓库。不能等同独立训练次数或模型家族数。',
   '下载是平台请求计数，不是独立用户、活跃使用、API调用、商业收入、付费或续费率；缓存、自动化、CI和文件格式影响数值。',
   '生态指标覆盖全部模型任务，包含语音、视觉、嵌入、分类和生成模型；与LLM性能梯度不同。',
   '任务标签缺失严重，生成式子集只能作下限，不能用于国家排序；N-ATLaS缺标签、Jacaranda模型多标为问答均可被漏算。',
   'HF的region:us标签表示Hub存储区域等平台元数据，不能当模型厂商国籍。',
   '国外基座的本地衍生仓库按发布机构计入当地样本，底座来源仍在逐repo数据中另列；不会重复转计为原基座国家的仓库。',
   '未纳入、账号迁移、接口失败、没有来源均显示null或待核；不得改成0。',
   '网页缓存与搜索摘要可能滞后或来自不同窗口；本表统一采用本次官方API快照，不混合搜索摘要数字。'
 ],
 'collection':{'endpoint':'https://huggingface.co/api/models?author={account}&limit=1000&full=true&cardData=true','pagination':'跟随Link rel=next直到无下一页；所有纳入账号分页已结束','authentication':'无登录、仅公开API','weightHeuristic':'.safetensors/.bin/.gguf/.pt/.pth/.ckpt/.h5/.npz/.onnx文件；排除optimizer/training_args/scheduler/rng_state及.bin/.onnx/.npz中的tokenizer/spiece/vocab/merges/dictionary文件；语音视觉神经tokenizer权重仍保留；仅验证文件列表，非检查权重完整性','deduplication':'仅以完整repo id去重；不跨精度、量化、版本或模型家族合并'},
 'sources':method_sources,'countries':countries,'accounts':accounts,
 'downloads':{'perRepoJson':'hf-repositories-20261107.json','fullApiArchive':'hf-raw-api-20261107.zip','collectorScript':'collect-hf-sample-20261107.py'}
}
(ROOT/'hf-ecosystem-sample-20261107.json').write_text(json.dumps(ecosystem,ensure_ascii=False,indent=2))

repo_export={'asOf':'2026-11-07','methodologyFile':'hf-ecosystem-sample-20261107.json','accounts':[{k:a[k] for k in ['account','countryMapping','fetchedAt','sourceUrl','paginationComplete','rows']} for a in raw['accounts']]}
(ROOT/'hf-repositories-20261107.json').write_text(json.dumps(repo_export,ensure_ascii=False,indent=2))
with zipfile.ZipFile(ROOT/'hf-raw-api-20261107.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for a in raw['accounts']:
        p=ROOT/'hf-snapshots-20261107'/(a['account']+'.raw.json');z.write(p,arcname=p.name)
    z.write(ROOT/'collect-hf-sample-20261107.py',arcname='collect-hf-sample-20261107.py')
    z.write(ROOT/'build-model-audit-20261107.py',arcname='build-model-audit-20261107.py')

corrections={
 'TH':{'status':'refine','finding':'Typhoon是分版本、多底座系列；文本版typhoon2-qwen2.5-7b使用Qwen2.5，视觉版另有Qwen2-VL。原笼统“Typhoon2使用Qwen2”需细化。HF账号已迁移为typhoon-ai，旧scb10x空列表不能写零。','suggestedText':'Typhoon 2含Llama 3系列、Qwen2.5文本版和Qwen2-VL视觉版；2.1使用Gemma 3；2.5使用Qwen3。按具体子版本核对底座。','sources':['https://huggingface.co/typhoon-ai/typhoon2-qwen2.5-7b-instruct','https://huggingface.co/typhoon-ai/typhoon2-qwen2vl-7b-vision-instruct','https://huggingface.co/collections/typhoon-ai/typhoon-25']},
 'DE':{'status':'retain_with_note','finding':'Pharia从零训练锚点成立，但国家归属应区分历史研发主体与现公司合并状态。2026-09签署Cohere合并协议，签约不等于已交割。','suggestedText':'Aleph Alpha为德国起源研发主体；已与Cohere签合并协议，当前控制权及交割另核。','sources':['https://www.prnewswire.com/news-releases/cohere-and-aleph-alpha-sign-agreement-to-become-the-first-transatlantic-sovereign-ai-solution-302880758.html']},
 'CA':{'status':'retain_with_note','finding':'Command原生体系锚点成立；Cohere跨国组织及与Aleph Alpha签约合并必须说明。不同Command版本许可不同，不能以2025版NC许可概括2026版。','suggestedText':'Cohere为加拿大起源跨国研发机构；按具体版本说明许可和权重控制。','sources':['https://cohere.com/blog/cohere-alephalpha-join-forces','https://huggingface.co/CohereLabs/c4ai-command-a-03-2025','https://huggingface.co/CohereLabs/command-a-plus-05-2026-bf16']},
 'SA':{'status':'retain_with_note','finding':'ALLaM论文包含从零7B与Llama2继续训练两条路线，原生档可保留；HF当前权重发布主体humain-ai与原研发SDAIA/NCAI需分列。','sources':['https://arxiv.org/html/2407.15390v1','https://huggingface.co/humain-ai/ALLaM-7B-Instruct-preview']},
 'ID':{'status':'retain_with_note','finding':'70B的Llama3.1路线可保留；v1部分版本实际经过AI Singapore SEA-LION中间底座，不能笼统描述全部由原始Meta/Google权重直接适配。','sources':['https://huggingface.co/Sahabat-AI/Llama-Sahabat-AI-v2-70B-IT','https://huggingface.co/Sahabat-AI/gemma2-9b-cpt-sahabatai-v1-base','https://huggingface.co/Sahabat-AI/llama3-8b-cpt-sahabatai-v1-base']},
 'NG':{'status':'retain_with_note','finding':'官方模型卡明确SFT及Llama-3 8B，足以适配层；精确Llama3 vs3.1子版本不应根据第三方模型树猜定。N-ATLaS缺pipeline标签，不代表不是生成模型。','sources':['https://huggingface.co/NCAIR1/N-ATLaS']},
 'GB':{'status':'retain_with_note','finding':'Stable LM 2历史预训练证据成立；英国研究所在地、Stability跨国控制与Google DeepMind的美国母公司控制应区分，不把英国全体研发能力说成仅1.6B。','sources':['https://stability.ai/news-updates/introducing-stable-lm-2']},
 'KE':{'status':'retain_with_note','finding':'UlizaLlama权重适配路线成立；Jacaranda为跨国非营利医疗项目，不能直接称肯尼亚国家主权模型。问答标签导致纯text-generation过滤遗漏。','sources':['https://huggingface.co/Jacaranda/UlizaLlama']},
 'CL':{'status':'retain_with_note','finding':'LatamGPT为Llama3.1 70B区域合作适配。国家分组以CENIA协调节点为约定，不重复分配所有参与国，也不称从零。','sources':['https://huggingface.co/latam-gpt/Llama-3.1-70B-LatamGPT-SFT-1.0']},
 'ZA':{'status':'retain_with_note','finding':'InkubaLM 0.4B从零证据保留，但必须显示小型研究基座，不以研发路线层级暗示性能胜过70B适配模型。','sources':['https://arxiv.org/abs/2408.17024']},
 'BR':{'status':'retain_with_note','finding':'Manacá实际1.72B从零训练、LNCC×日本NII合作可支撑原生档。不要以Tucano葡语名称或Sabiá商业名称代替训练谱系证据。','sources':['https://huggingface.co/AIInstituteLNCC/manaca-1b-base','https://arxiv.org/html/2603.10213v1']}
}
audit_rows=[]
for c in old['countries']:
    r={'iso':c['iso'],'country':c['country'],'existingTier':c['tier'],'recommendedTier':c['tier'],
       'status':'pending' if c['tier']=='U' else 'retain',
       'finding':'保留待核，不将搜索未发现或未纳入账号写成无自主模型。' if c['tier']=='U' else '已给出的原始机构文档/模型卡支持该训练路线作为最高已核能力下限；所列版本是历史能力锚点，不宣称2026最新或最强。',
       'sources':[s['url'] for s in c.get('sources',[])]}
    if c['iso'] in corrections:r.update(corrections[c['iso']])
    r['hfSampleAccounts']=[a['account'] for a in accounts if a['countryMapping']==c['iso']]
    audit_rows.append(r)

audit={
 'schemaVersion':'1.0','asOf':'2026-11-07','auditedFile':'ai-capacity-atlas/evidence/models-31-countries.json',
 'auditBasis':'复核既有逐国原始证据与训练路径；补查当前HF官方账号/模型元数据及关键争议原始来源。开发者披露不等于独立复现训练，本表只审计可支持的事实边界。',
 'summary':{'countriesReviewed':31,'tierChanges':0,'explicitTextRefinements':['TH'],'scopeOrAttributionNotes':['GB','DE','CA','SA','ID','NG','KE','CL','ZA','BR'],'pendingCountries':['MX','AR','PH','PK','BD','ET']},
 'globalCorrections':[
   '层级名称建议明确“研发路线最高已核能力”；从零0.4B不能与750B能力等价，模型质量/规模/训练路线三列并列。',
   '当前榜单无API或未评测不是该国无模型。AA首页当前默认图只是选中28/725模型，不能写AA仅有三个国家上榜。',
   '公开权重仓库数、下载量均不得作为全国开源模型总数、独立模型家族数、用户数、AI付费收入或国家市场占有率。',
   '国家下方展示多家代表机构，保留具体模型作为证据锚点；不能以榜首单模型替代整个国家模型体系。'
 ],
 'aaHomepage':{'url':'https://artificialanalysis.ai/','checkedAt':'2026-11-07','benchmarkVersion':'Artificial Analysis Intelligence Index v5.0.1','homepageSelectedModels':28,'catalogModelsShownByPage':725,
   'note':'以下是首页Intelligence Index vs. Cost per Task图例出现的模型创作者集合；非全国厂商普查、非按显示顺序排名。父任务另核完整榜单加拿大/韩国等来源。',
   'creatorsByPublisherCountry':{'US':['Google','OpenAI','Anthropic','Meta','SpaceXAI','NVIDIA','Thinking Machines','Reflection'],'CN':['Kimi','Alibaba','DeepSeek','Z AI','Tencent','MiniMax','Xiaomi','InclusionAI'],'FR':['Mistral']},
   'attributionCaveat':'归属按发布公司主要归属；Google/DeepMind跨国研发，SpaceXAI按AA当前品牌显示。图例中的创作者不是API托管平台。'},
 'countries':audit_rows,
 'hfDataset':'hf-ecosystem-sample-20261107.json','hfPerRepoSnapshot':'hf-repositories-20261107.json','hfRawArchive':'hf-raw-api-20261107.zip',
 'dataQualityChecks':{'allSelectedAccountsPaginationComplete':all(a['paginationComplete'] for a in accounts),'uniqueRepoIds':len({r['id'] for a in raw['accounts'] for r in a['rows']}),'sumAccountPublicRepos':sum(a['publicRepoCount'] for a in accounts),'accountMigrationsHandled':[{'old':'scb10x','current':'typhoon-ai','oldEmptyNotTreatedAsZero':True},{'old':'ALLaM-AI','current':'humain-ai','note':'使用当前账号；不重复聚合别名'},{'old':'CohereForAI','current':'CohereLabs','note':'只计当前账号，不重复旧别名'}]},
 'methodSources':method_sources
}
(ROOT/'audit-models-20261107.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print('ecosystem:',ROOT/'hf-ecosystem-sample-20261107.json')
print('audit:',ROOT/'audit-models-20261107.json')
for c in countries:
 print(c['iso'],c['accountCount'],c['weightArtifactRepoCount'],c['weightArtifactDownloads30d'])
